# Dataset Partitions

Partition specifications for the four data-driven tasks (paper Section 6.2).
Raw media is reproduced from these manifests; only partition definitions,
split parameters, and ground-truth annotations are stored here.

| Folder | Task | Key files | Paper ref |
|--------|------|-----------|-----------|
| `gpd/` | Product detection | `partition_config.yaml`, `test.txt` (1,664), `val.txt` (247), `classes.txt` (251), `condition_tags.csv`, `train_synthetic_manifest.txt` | §5.1, §6.2, Table 6 |
| `ocr/` | Shelf-label OCR | `partition_config.yaml`, `label_crops.csv` (4,992) | §5.2, §6.3, Table 6 |
| `voice/` | Voice ASR | `partition_config.yaml`, `utterances.csv` (1,200), `speakers.csv` (24) | §5.3, §6.2 |
| `tracking/` | Person tracking | `partition_config.yaml`, `gt.txt` (MOT), `seqinfo.ini` | §5.5, §6.2 |
| `navigation/` | Navigation/ablation | `benchmark_config.yaml` | §6.2, §6.5, Table 5 |

## Notes
- **GPD train** is 2.4M Omniverse synthetic renders; `train_synthetic_manifest.txt`
  lists 1,200 scene templates (×2,000 randomized renders) with reproduction seeds.
  The detector is *evaluated* on the public GPD test split.
- **Voice** and **tracking** sets are evaluation-only (models are not fine-tuned
  on them), so each defines a single `test` partition.
- `condition_tags.csv` maps each GPD test image to one of the six lighting/motion
  conditions in Table 6.
