# TensorRT Engine Configurations

One JSON per model with the exact `trtexec` build parameters, stream/priority
assignment (Table 1), and reference latency/accuracy (Table 2). `build_engines.sh`
compiles all five engines under the mixed-precision policy (Table 3).

| Config | Task | Precision | Stream / prio | Ref latency |
|--------|------|-----------|---------------|-------------|
| `depthanything_v2s_int8.json` | Obstacle detection | INT8 | S1 / −1 | 21 ms |
| `yolov8l_fp16.json` | Product detection | FP16 | S3 / 0 | 12 ms |
| `ppocrv4_v4_fp16.json`* | Shelf-label OCR | FP16 | S4 / 0 | 45 ms |
| `bytetrack_reid_fp16.json` | Person tracking | FP16 | S5 / 0 | 18 ms |
| `whisper_small_en_fp16.json` | Voice ASR | FP16 | S5* async | 180 ms |

(*file is `paddleocr_v4_fp16.json`)

ONNX models go in `models/`; engines and INT8 caches are written to `engines/`.
Place exported ONNX files there before running `build_engines.sh`.

`build_precision_study.sh` builds FP32/FP16/INT8 variants of all five tasks to
reproduce the **Table 2** precision study (the JSON configs + `build_engines.sh`
cover only the deployed mixed-precision set from Table 3).

Common build settings (all engines): explicit batch 1, 50 warm-up + 500 timing
runs, JetPack 5.1.2 / CUDA 11.4 / TensorRT 8.5.2.
