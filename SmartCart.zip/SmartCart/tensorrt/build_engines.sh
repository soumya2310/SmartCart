#!/usr/bin/env bash
# =============================================================================
# build_engines.sh — Compile all five TensorRT engines on Jetson AGX Orin
# Paper: Section 6.1, Tables 1-3
# Platform: JetPack 5.1.2 / CUDA 11.4 / cuDNN 8.6 / TensorRT 8.5.2
# Mixed-precision policy (Table 3): INT8 obstacle detection, FP16 elsewhere.
# =============================================================================
set -euo pipefail

TRTEXEC="${TRTEXEC:-/usr/src/tensorrt/bin/trtexec}"
ONNX_DIR="${ONNX_DIR:-models}"
ENGINE_DIR="${ENGINE_DIR:-engines}"
CALIB_DIR="${CALIB_DIR:-../calibration}"
mkdir -p "${ENGINE_DIR}"

echo "==> [S1] DepthAnything v2-S  (INT8, priority -1, obstacle detection)"
python3 "${CALIB_DIR}/generate_calibration.py" \
    --model depthanything_v2s \
    --config "${CALIB_DIR}/depthanything_calib.yaml" \
    --cache "${ENGINE_DIR}/depthanything_v2s_int8.cache"
"${TRTEXEC}" \
    --onnx="${ONNX_DIR}/depthanything_v2s.onnx" \
    --saveEngine="${ENGINE_DIR}/depthanything_v2s_int8.engine" \
    --int8 --useCudaGraph \
    --calib="${ENGINE_DIR}/depthanything_v2s_int8.cache" \
    --shapes=input:1x3x518x518 \
    --workspace=4096 --warmUp=50 --iterations=500 --avgRuns=500

echo "==> [S3] YOLOv8-L  (FP16, product detection)"
"${TRTEXEC}" \
    --onnx="${ONNX_DIR}/yolov8l.onnx" \
    --saveEngine="${ENGINE_DIR}/yolov8l_fp16.engine" \
    --fp16 --useCudaGraph \
    --shapes=images:1x3x640x640 \
    --workspace=4096 --warmUp=50 --iterations=500 --avgRuns=500

echo "==> [S4] PaddleOCR v4  (FP16, shelf label OCR)"
"${TRTEXEC}" --onnx="${ONNX_DIR}/ppocrv4_det.onnx" \
    --saveEngine="${ENGINE_DIR}/ppocrv4_det_fp16.engine" \
    --fp16 --shapes=x:1x3x960x960 --workspace=2048
"${TRTEXEC}" --onnx="${ONNX_DIR}/ppocrv4_rec.onnx" \
    --saveEngine="${ENGINE_DIR}/ppocrv4_rec_fp16.engine" \
    --fp16 --shapes=x:1x3x48x320 --workspace=2048

echo "==> [S5] ByteTrack + ReID  (FP16, person tracking)"
"${TRTEXEC}" --onnx="${ONNX_DIR}/bytetrack_det.onnx" \
    --saveEngine="${ENGINE_DIR}/bytetrack_det_fp16.engine" \
    --fp16 --shapes=images:1x3x800x1440 --workspace=2048
"${TRTEXEC}" --onnx="${ONNX_DIR}/reid_resnet50.onnx" \
    --saveEngine="${ENGINE_DIR}/reid_resnet50_fp16.engine" \
    --fp16 --shapes=input:1x3x256x128 --workspace=2048

echo "==> [S5*] Whisper Small.en  (FP16, async voice ASR)"
"${TRTEXEC}" --onnx="${ONNX_DIR}/whisper_small_en_encoder.onnx" \
    --saveEngine="${ENGINE_DIR}/whisper_small_en_encoder_fp16.engine" \
    --fp16 --shapes=mel:1x80x3000 --workspace=4096
"${TRTEXEC}" --onnx="${ONNX_DIR}/whisper_small_en_decoder.onnx" \
    --saveEngine="${ENGINE_DIR}/whisper_small_en_decoder_fp16.engine" \
    --fp16 --workspace=4096

echo "==> All engines built in ${ENGINE_DIR}/"
