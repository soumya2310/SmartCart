#!/usr/bin/env bash
# =============================================================================
# build_precision_study.sh — Reproduce Table 2 (TensorRT precision study)
# Builds FP32, FP16, and INT8 engines for ALL FIVE tasks so the full
# accuracy-latency Pareto comparison can be measured.
#   - build_engines.sh builds only the DEPLOYED mixed-precision set (Table 3).
#   - THIS script builds the 13 study engines behind Table 2's numbers.
# Platform: JetPack 5.1.2 / CUDA 11.4 / TensorRT 8.5.2
# =============================================================================
set -euo pipefail

TRTEXEC="${TRTEXEC:-/usr/src/tensorrt/bin/trtexec}"
ONNX_DIR="${ONNX_DIR:-models}"
OUT="${OUT:-engines/study}"
CALIB_DIR="${CALIB_DIR:-../calibration}"
mkdir -p "${OUT}"

# task | onnx stem | input binding=shape
TASKS=(
  "yolov8l|yolov8l|images:1x3x640x640"
  "ppocrv4_rec|ppocrv4_rec|x:1x3x48x320"
  "whisper_small_en_encoder|whisper_small_en_encoder|mel:1x80x3000"
  "depthanything_v2s|depthanything_v2s|input:1x3x518x518"
  "bytetrack_det|bytetrack_det|images:1x3x800x1440"
)

build () {  # $1 name  $2 onnx  $3 shape  $4 precision  $5 extra-flags
  local name=$1 onnx=$2 shape=$3 prec=$4; shift 4
  echo "==> ${name} [${prec}]"
  "${TRTEXEC}" \
    --onnx="${ONNX_DIR}/${onnx}.onnx" \
    --saveEngine="${OUT}/${name}_${prec}.engine" \
    --shapes="${shape}" --workspace=4096 \
    --warmUp=50 --iterations=500 --avgRuns=500 "$@"
}

for row in "${TASKS[@]}"; do
  IFS='|' read -r name onnx shape <<< "${row}"

  # FP32 (baseline)
  build "${name}" "${onnx}" "${shape}" "fp32"

  # FP16
  build "${name}" "${onnx}" "${shape}" "fp16" --fp16

  # INT8 (needs a calibration cache for this model)
  echo "    generating INT8 calibration cache for ${name}"
  python3 "${CALIB_DIR}/generate_calibration.py" \
      --model "${name}" \
      --config "${CALIB_DIR}/$(echo "${name}" | sed 's/_rec//;s/_encoder//;s/_det//')_calib.yaml" \
      --cache "${OUT}/${name}_int8.cache" || \
      echo "    (config name fallback — see calibration/ for the matching *_calib.yaml)"
  build "${name}" "${onnx}" "${shape}" "int8" \
      --int8 --calib="${OUT}/${name}_int8.cache"
done

echo ""
echo "==> Precision-study engines in ${OUT}/ (5 tasks x {fp32,fp16,int8})"
echo "    Measure latency from trtexec avgRuns output; accuracy via the"
echo "    per-task eval protocol in datasets/*/partition_config.yaml -> Table 2."
