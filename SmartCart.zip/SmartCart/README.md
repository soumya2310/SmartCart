# SmartCart — Replication Package

Supplementary artifacts for **"Real-Time Multi-Task Edge AI for Retail Navigation:
Parallel Deep Learning Pipeline Design, TensorRT Quantisation, and Benchmark
Evaluation on NVIDIA Jetson AGX Orin"** (Chattopadhyay).

This package provides the **dataset partitions, TensorRT engine configurations,
calibration parameters, and Gazebo simulation configurations** referenced in the
paper's Data Availability statement.

> **Scope note.** Raw image corpora, audio, and compiled `.engine`/`.cache`
> binaries are *generated* on the target hardware from the specifications here —
> they are not redistributed (the 2.4M synthetic renders, the live-store
> recordings, and platform-specific TensorRT engines are not portable). Every
> file needed to *reproduce* those binaries deterministically is included:
> partition manifests, split seeds, build flags, calibration settings, and the
> full Gazebo world/robot/launch stack.

## Layout

```
SmartCart/
├── datasets/        # partition manifests + split parameters (4 tasks)
│   ├── gpd/         # product detection — GPD test/val + synthetic train manifest
│   ├── voice/       # ASR — 1,200 utterances, 24 speakers, 4 noise levels
│   ├── tracking/    # MOT — 3,000-frame sequence, 24 pedestrians (gt.txt)
│   ├── ocr/         # shelf-label OCR crops (Tables 2, 6)
│   └── navigation/  # ablation + benchmark trial config (Table 5)
├── tensorrt/        # per-model trtexec build configs + build_engines.sh
├── calibration/     # INT8 PTQ params, 512-image manifests, cache generator
└── gazebo/          # 4,800 m² world, robot URDF, Nav2/AMCL, launch
```

## Target platform (paper Section 6.1)

| Component | Version |
|-----------|---------|
| Module    | NVIDIA Jetson AGX Orin 64 GB |
| OS        | Ubuntu 20.04 |
| JetPack   | 5.1.2 |
| CUDA / cuDNN / TensorRT | 11.4 / 8.6 / 8.5.2 |
| ROS 2 / Gazebo | Humble / Classic 11 |

## Quick start

```bash
# 1. Build all five TensorRT engines (mixed precision per Table 3)
cd tensorrt && ONNX_DIR=models ./build_engines.sh

# 2. Launch the Gazebo benchmark (baseline condition)
ros2 launch smartcart_sim retail_navigation.launch.py \
    lighting_profile:=fluorescent_500lux n_pedestrians:=4 ablation_disable:=none

# 3. Reproduce an ablation row (Table 5), e.g. disable obstacle detection
ros2 launch smartcart_sim retail_navigation.launch.py ablation_disable:=S1
```

## Mixed-precision policy (Table 3)

| Task | Stream | Precision | Latency | Why |
|------|--------|-----------|---------|-----|
| Obstacle detection | S1 (prio −1) | **INT8** | 21 ms | only −0.3 pp recall; latency critical |
| Product detection  | S3 | FP16 | 12 ms | −4.4 pp INT8 penalty unacceptable |
| Shelf-label OCR    | S4 | FP16 | 45 ms | −5.1 pp INT8 penalty (softmax sensitivity) |
| Person tracking    | S5 | FP16 | 18 ms | ReID embedding quality |
| Voice ASR          | S5* (async) | FP16 | 180 ms | INT8 raises WER |
| **End-to-end (parallel)** | — | Mixed | **85 ms** | 3.3× faster than sequential |

## Reproducibility seeds

| Artifact | Seed |
|----------|------|
| GPD val/test split | 1729 |
| Voice partition | 2310 |
| Tracking trajectories | 42 |
| INT8 calibration sampling | 512 |
| Ablation goal sampling | 97 |

All numeric references in these configs are traceable to the paper's tables.
See each subfolder's `README.md` for details.
