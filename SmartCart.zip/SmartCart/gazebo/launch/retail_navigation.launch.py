#!/usr/bin/env python3
# =============================================================================
# retail_navigation.launch.py — Bring up the SmartCart Gazebo benchmark
# Paper: Section 6.2, 6.5  | ROS 2 Humble + Gazebo Classic 11 + Nav2
#
# Args:
#   lighting_profile : fluorescent_500lux | led_700lux | led_200lux |
#                      mixed | motion_fluorescent | motion_led_dim   (Table 6)
#   n_pedestrians    : crowd density for tracking/ablation (2..8)
#   ablation_disable : none | S1 | S2 | S3 | S4 | S5_track | S5_voice (Table 5)
# =============================================================================
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    pkg = FindPackageShare("smartcart_sim")

    lighting = LaunchConfiguration("lighting_profile")
    n_ped = LaunchConfiguration("n_pedestrians")
    ablation = LaunchConfiguration("ablation_disable")

    world = PathJoinSubstitution([pkg, "worlds", "retail_store.world"])
    urdf = PathJoinSubstitution([pkg, "urdf", "smartcart.urdf.xacro"])
    nav2_params = PathJoinSubstitution([pkg, "config", "nav2_params.yaml"])
    amcl_params = PathJoinSubstitution([pkg, "config", "amcl_params.yaml"])
    map_yaml = PathJoinSubstitution([pkg, "maps", "retail_store.yaml"])

    return LaunchDescription([
        DeclareLaunchArgument("lighting_profile", default_value="fluorescent_500lux"),
        DeclareLaunchArgument("n_pedestrians", default_value="4"),
        DeclareLaunchArgument("ablation_disable", default_value="none"),

        # Gazebo + world
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                FindPackageShare("gazebo_ros"), "/launch/gazebo.launch.py"]),
            launch_arguments={"world": world}.items()),

        # Robot state + spawn
        Node(package="robot_state_publisher", executable="robot_state_publisher",
             parameters=[{"robot_description": ["xacro ", urdf]}]),
        Node(package="gazebo_ros", executable="spawn_entity.py",
             arguments=["-topic", "robot_description", "-entity", "smartcart",
                        "-x", "-35", "-y", "0", "-z", "0.15"]),

        # Lighting controller — applies Table 6 illuminance/motion profile
        Node(package="smartcart_sim", executable="lighting_controller",
             parameters=[{"profile": lighting}]),

        # Pedestrian spawner for tracking / ablation trials
        Node(package="smartcart_sim", executable="spawn_pedestrians",
             parameters=[{"n_pedestrians": n_ped, "seed": 42}]),

        # Map server — serves the 4,800 m² occupancy grid to AMCL + static layer
        Node(package="nav2_map_server", executable="map_server",
             name="map_server", output="screen",
             parameters=[{"use_sim_time": True, "yaml_filename": map_yaml}]),
        Node(package="nav2_lifecycle_manager", executable="lifecycle_manager",
             name="lifecycle_manager_localization", output="screen",
             parameters=[{"use_sim_time": True, "autostart": True,
                          "node_names": ["map_server", "amcl"]}]),

        # Localisation (AMCL, S2 priority slot)
        Node(package="nav2_amcl", executable="amcl",
             parameters=[amcl_params], output="screen"),

        # Nav2 bringup (DWB planner)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                FindPackageShare("nav2_bringup"), "/launch/navigation_launch.py"]),
            launch_arguments={"params_file": nav2_params,
                              "use_sim_time": "true"}.items()),

        # Five-stream inference manager (reads ../tensorrt engine configs)
        Node(package="smartcart_inference", executable="stream_manager",
             parameters=[{
                 "engine_dir": "../tensorrt/engines",
                 "priority_aware": True,         # Algorithm 1
                 "obstacle_precision": "int8",   # S1, priority -1
                 "ablation_disable": ablation,
                 "cycle_budget_ms": 100,
                 "sync_barrier_ms": 80,          # CUDA event barrier (Section 4.3)
             }], output="screen"),

        # Benchmark trial runner (500 trials/condition, logs nav_accuracy + collisions)
        Node(package="smartcart_sim", executable="benchmark_runner",
             parameters=[{"trials": 500, "goal_tolerance_m": 0.25,
                          "ablation_disable": ablation}]),
    ])
