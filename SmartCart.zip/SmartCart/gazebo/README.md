# Gazebo Simulation Configurations

Replicable 4,800 m² retail-store environment (paper §6.2, §6.5).
ROS 2 Humble + Gazebo Classic 11 + Nav2.

| Path | Purpose |
|------|---------|
| `worlds/retail_store.world` | 80×60 m store, walls, gondola aisles, configurable lighting |
| `urdf/smartcart.urdf.xacro` | Cart base + 2D LiDAR + RealSense D455, diff-drive (0.8 m/s cap) |
| `config/amcl_params.yaml` | AMCL particle filter, mixed beam model, depth fusion (§3.3) |
| `config/nav2_params.yaml` | DWB local planner, costmaps, 100 ms controller cycle |
| `launch/retail_navigation.launch.py` | Full bring-up with lighting/pedestrian/ablation args |

## Launch arguments
- `lighting_profile` — one of the six Table 6 conditions.
- `n_pedestrians` — crowd density 2–8 (tracking/ablation).
- `ablation_disable` — `none|S1|S2|S3|S4|S5_track|S5_voice` (Table 5 rows).

The launch wires the five-stream inference manager to `../tensorrt/engines`,
enables priority-aware scheduling (Algorithm 1), and runs the 500-trial
benchmark with a 0.25 m goal tolerance and an 80 ms CUDA sync barrier (§4.3).
