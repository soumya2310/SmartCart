# Gazebo Models

- `pedestrian_actor.sdf` — animated pedestrian actor. `spawn_pedestrians`
  instances this 2–8 times (launch arg `n_pedestrians`) with per-instance
  randomized waypoint trajectories (seed 42) that reproduce the motion in
  `datasets/tracking/gt.txt`.
- Store geometry (walls, gondola aisles) is defined inline in
  `../worlds/retail_store.world`; `sun` and `ground_plane` are Gazebo built-ins.
