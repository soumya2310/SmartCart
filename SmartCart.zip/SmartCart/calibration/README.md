# INT8 Calibration Parameters

Post-training quantisation settings (paper §3.2, §6.1). Entropy-minimisation
calibrator (`IInt8EntropyCalibrator2`), **512** images per model, **per-channel**
symmetric scale factors.

- `int8_calibration_config.yaml` — global settings + quantisation error model
  + per-task INT8 accuracy deltas (Table 2).
- `depthanything_calib.yaml` — the **only** model deployed at INT8 (S1). Keeps the
  metric-alignment head in FP16 to protect scale-and-shift (§5.4).
- `{yolov8l,ppocrv4,bytetrack,whisper}_calib.yaml` — characterisation configs for
  the four FP16-deployed models (used to produce the INT8 column of Table 2).
- `calib_images_*.txt` — 512-sample manifests per model (seed 512).
- `generate_calibration.py` — builds the on-disk calibration cache; falls back to
  a documented placeholder when TensorRT/CUDA is absent, so the pipeline is
  reproducible end-to-end (regenerate on the Jetson for real scale factors).

## Why per-task precision (§3.2)
INT8 error variance ≈ s²/12 is ~65× larger than FP16. Detection activations are
smooth/Gaussian (INT8-tolerant); OCR/ReID rely on high-dynamic-range softmax/
embedding layers where INT8 scale misalignment inflates error — hence FP16 for
those and INT8 only for obstacle detection.
